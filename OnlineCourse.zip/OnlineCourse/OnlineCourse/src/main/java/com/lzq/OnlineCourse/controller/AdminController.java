package com.lzq.OnlineCourse.controller;

import com.lzq.OnlineCourse.biz.AdminBiz;
import com.lzq.OnlineCourse.entity.Admin;
import com.lzq.OnlineCourse.entity.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
@RestController
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    private AdminBiz biz;
    @RequestMapping("/list")
    public Map findAll(){
        List<Admin> list = biz.getAdList();
        Map map = new HashMap();
        map.put("isOk",true);
        map.put("students", list);
        map.put("msg","查询成功");
        return map;
    }

    @RequestMapping("/del")
    public Map del(String id){
        boolean isOk = biz.removeAd(id);
        Map map = new HashMap();
        if(isOk){
            map.put("isOk",true);
            map.put("msg","删除成功");
        }else{
            map.put("isOk",false);
            map.put("msg","删除失败");
        }
        return map;
    }
    @RequestMapping("/add")
    public Map add(Admin stu){
        boolean isOk = biz.addAd(stu);
        Map map = new HashMap();
        if(isOk){
            System.out.println(stu.getId());
            map.put("isOk",true);
            map.put("msg","注册成功");
        }else{
            map.put("isOk",false);
            map.put("msg","注册失败");
        }
        return map;
    }
    @RequestMapping("/login")
    public Map login(Admin ad, HttpSession session){
        ad = biz.checkLogin(ad);
        session.setAttribute("login_ad",ad);
        Map map = new HashMap();
        map.put("isOk",true);
        map.put("login_ad",ad);
        map.put("msg","登录成功");
        return map;
    }

    @RequestMapping("/logouot")
    public Map logout(HttpSession session){
        Map map = new HashMap();
        try {
            session.invalidate();
            map.put("isOk",true);
            map.put("msg","退出成功");
        }catch (Exception e){
            map.put("isOk",false);
            map.put("msg","退出失败："+e.getMessage());
        }
        return map;
    }

    @RequestMapping("/selectid")
    public Map findById(@RequestParam String id){
        Admin admin = biz.getAdById(id);
        Map result = new HashMap<>();
        if(admin!=null){
            result.put("isOk", true);
            result.put("admin", admin);
            result.put("msg", "查询成功");
        } else {
            result.put("isOk", false);
            result.put("msg", "未找到管理员");
        }
        return result;

    }

    public void setBiz(AdminBiz biz) {
        this.biz = biz;
    }
}
