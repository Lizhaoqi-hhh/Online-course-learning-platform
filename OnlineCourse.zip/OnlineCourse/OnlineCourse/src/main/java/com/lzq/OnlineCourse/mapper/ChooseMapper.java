package com.lzq.OnlineCourse.mapper;

import com.lzq.OnlineCourse.entity.Choose;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ChooseMapper {
    @Select("select * from t_choose")
    List<Choose> selectChoose();

    @Select("select * from t_choose where ID=#{id}")
    Choose selectChooseById(int id);//by name?

    @Select("select * from t_course where title=#{title}")
    Choose selectChooseByTitle(String title);

    @Select("select * from t_choose where title=#{title}")
    Choose selectChooseByTitle1(String title);

    @Insert("insert into t_choose values (#{id},#{title},#{num},#{price},#{teacher},#{info})")
    int insertChoose(Choose choose);

    @Delete("delete from t_choose where ID=#{id}")
    int deleteChooseById(int id);
}
