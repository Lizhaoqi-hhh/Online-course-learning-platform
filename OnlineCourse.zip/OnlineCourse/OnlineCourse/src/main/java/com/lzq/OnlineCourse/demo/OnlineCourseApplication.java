package com.lzq.OnlineCourse.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.lzq.OnlineCourse")
public class OnlineCourseApplication {
    public static void main(String[] args) {
        SpringApplication.run(OnlineCourseApplication.class, args);
    }
}
