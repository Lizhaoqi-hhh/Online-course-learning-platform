package com.lzq.OnlineCourse.biz;

import com.lzq.OnlineCourse.entity.Choose;
import com.lzq.OnlineCourse.mapper.ChooseMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ChooseBiz {
    @Autowired  //由Spring创建对象并通过setter方法注入
    private ChooseMapper mapper;

    public List<Choose> getChooseList(){
        return mapper.selectChoose();
    }

    public Choose getChooseById(int id){
        return mapper.selectChooseById(id);
    }

    public Choose getChooseByTitle(String title){
        return this.mapper.selectChooseByTitle(title);
    }

    public Choose getChooseByTitle1(String title){
        return this.mapper.selectChooseByTitle1(title);
    }

    public boolean addChoose(Choose choose){
        return mapper.insertChoose(choose)>0;
    }
    public boolean removeChoose(int id){
        return mapper.deleteChooseById(id)>0;
    }

    public void setMapper(ChooseMapper mapper) {
        this.mapper = mapper;
    }
}
