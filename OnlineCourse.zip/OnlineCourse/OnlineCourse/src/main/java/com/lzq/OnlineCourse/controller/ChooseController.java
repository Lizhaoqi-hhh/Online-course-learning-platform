package com.lzq.OnlineCourse.controller;

import com.lzq.OnlineCourse.biz.ChooseBiz;
import com.lzq.OnlineCourse.entity.Choose;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/choose")
public class ChooseController {
    @Autowired
    private ChooseBiz biz;
    @RequestMapping("/list")
    public Map findAll(){
        List<Choose> list = biz.getChooseList();
        Map map = new HashMap();
        map.put("isOk",true);
        map.put("courses", list);
        map.put("msg","选课信息加载成功");
        return map;
    }

    @RequestMapping("/select")
    public Map findByTitle(@RequestParam String title){
        Choose courses = biz.getChooseByTitle(title);
        Map result = new HashMap<>();
        if(courses!=null){
            result.put("isOk", true);
            result.put("courses", courses);
            result.put("msg", "查询成功");
        } else {
            result.put("isOk", false);
            result.put("msg", "未找到相关课程");
        }
        return result;
    }

    @RequestMapping("/select1")
    public Map findByTitle1(@RequestParam String title){
        Choose courses = biz.getChooseByTitle1(title);
        Map result = new HashMap<>();
        if(courses!=null){
            result.put("isOk", true);
            result.put("courses", courses);
            result.put("msg", "查询成功");
        } else {
            result.put("isOk", false);
            result.put("msg", "未找到相关课程");
        }
        return result;
    }

    @RequestMapping("/del")
    public Map del(int id){
        boolean isOk = biz.removeChoose(id);
        Map map = new HashMap();
        if(isOk){
            map.put("isOk",true);
            map.put("msg","删除成功");
        }else{
            map.put("isOk",false);
            map.put("msg","删除失败");
        }
        return map;
    }
    @RequestMapping("/add")
    public Map add(Choose choose){
        boolean isOk = biz.addChoose(choose);
        Map map = new HashMap();
        if(isOk){
            System.out.println("id:"+choose.getId());
            map.put("isOk",true);
            map.put("msg","添加成功");
        }else{
            map.put("isOk",false);
            map.put("msg","添加失败");
        }
        return map;
    }
    public void setBiz(ChooseBiz biz) {
        this.biz = biz;
    }
}
