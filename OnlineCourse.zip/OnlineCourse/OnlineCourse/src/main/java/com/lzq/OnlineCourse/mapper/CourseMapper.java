package com.lzq.OnlineCourse.mapper;

import com.lzq.OnlineCourse.entity.Course;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CourseMapper {
    @Select("select * from t_course")
    List<Course> selectCourse();

    @Select("select * from t_course where id=#{id}")
    Course selectCourseById(int id);

    @Select("select * from t_course where title=#{title}")
    Course selectCourseByTitle(String title);

    @Insert("insert into t_course values (#{id},#{title},#{num},#{price},#{teacher},#{info})")
    int insertCourse(Course course);

    @Delete("delete from t_course where ID=#{id}")
    int deleteCourseById(int id);

    @Update("update t_course set id=#{id},title=#{title},num=#{num},price=#{price},teacher=#{teacher},info=#{info} where id=#{id}")
    void updateCourse(Course course);
}
