package com.lzq.OnlineCourse.controller;

import com.lzq.OnlineCourse.biz.CourseBiz;
import com.lzq.OnlineCourse.entity.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
@RestController
@RequestMapping("/course")
public class CourseController {
    @Autowired
    private CourseBiz biz;
    @RequestMapping("/list")
    public Map findAll(){
        List<Course> list = biz.getCourseList();
        Map map = new HashMap();
        map.put("isOk",true);
        map.put("courses", list);
        map.put("msg","课程数据加载成功");
        return map;
    }

    @RequestMapping("/select")
    public Map findByTitle(@RequestParam String title){
        Course courses = biz.getCourseByTitle(title);
        Map result = new HashMap<>();
        if(courses!=null){
            result.put("isOk", true);
            result.put("courses", courses);
            result.put("msg", "查询成功");
        } else {
            result.put("isOk", false);
            result.put("msg", "未找到相关课程");
        }
        return result;
    }

    @RequestMapping("/del")
    public Map del(int id){
        boolean isOk = biz.removeCourse(id);
        Map map = new HashMap();
        if(isOk){
            map.put("isOk",true);
            map.put("msg","删除成功");
        }else{
            map.put("isOk",false);
            map.put("msg","删除失败");
        }
        return map;
    }
    @RequestMapping("/add")
    public Map add(Course course){
        boolean isOk = biz.addCourse(course);
        Map map = new HashMap();
        if(isOk){
            System.out.println("id:"+course.getId());
            map.put("isOk",true);
            map.put("msg","添加成功");
        }else{
            map.put("isOk",false);
            map.put("msg","添加失败");
        }
        return map;
    }

    @RequestMapping("/update")
    public Map update(Course course){
        this.biz.updateCourse(course);
        Map result = new HashMap<>();
        result.put("isOk",true);
        result.put("msg","修改成功");
        result.put("course",course);
        return result;
    }
    public void setBiz(CourseBiz biz) {
        this.biz = biz;
    }
}
