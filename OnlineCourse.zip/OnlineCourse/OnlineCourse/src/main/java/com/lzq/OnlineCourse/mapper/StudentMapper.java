package com.lzq.OnlineCourse.mapper;

import com.lzq.OnlineCourse.entity.Course;
import com.lzq.OnlineCourse.entity.Student;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface StudentMapper {
    @Select("select * from t_stu")
    List<Student> selectStus();

    @Select("select * from t_stu where ID=#{id}")
    Student selectStuById(String id);

    @Select("select * from t_stu where name=#{name}")
    Student selectStudentByName(String name);

    @Insert("insert into t_stu values (#{id},#{name},#{pwd},#{grade},#{phone})")
    int insertStu(Student stu);

    @Delete("delete from t_stu where ID=#{id}")
    int deleteStuById(String id);

    @Update("update t_stu set id=#{id},name=#{name},pwd=#{pwd},grade=#{grade},phone=#{phone} where id=#{id}")
    void updateStudent(Student student);
}
