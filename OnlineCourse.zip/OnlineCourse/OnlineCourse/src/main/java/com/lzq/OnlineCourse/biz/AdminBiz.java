package com.lzq.OnlineCourse.biz;

import com.lzq.OnlineCourse.entity.Admin;
import com.lzq.OnlineCourse.entity.Student;
import com.lzq.OnlineCourse.mapper.AdminMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class AdminBiz {
    @Autowired  //由Spring创建对象并通过setter方法注入
    private AdminMapper mapper;

    public List<Admin> getAdList(){
        return mapper.selectAd();
    }

    public Admin getAdById(String id){
        return this.mapper.selectAdById(id);
    }

    public boolean addAd(Admin stu){
        return mapper.insertAd(stu)>0;
    }
    public boolean removeAd(String id){
        return mapper.deleteAdById(id)>0;
    }

    public Admin checkLogin(Admin ad){
        Admin dbad = mapper.selectAdById(ad.getId());
        if(dbad!=null && dbad.getPwd().equals(ad.getPwd())){
            dbad.setPwd(null);
            return dbad;
        }else {
            throw new RuntimeException("登录失败");
        }
    }

    public void setMapper(AdminMapper mapper) {
        this.mapper = mapper;
    }
}
