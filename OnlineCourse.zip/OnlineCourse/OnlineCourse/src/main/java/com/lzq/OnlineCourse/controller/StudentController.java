package com.lzq.OnlineCourse.controller;

import com.lzq.OnlineCourse.biz.StudentBiz;
import com.lzq.OnlineCourse.entity.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
@RestController
@RequestMapping("/student")
public class StudentController {
    @Autowired
    private StudentBiz biz;
    @RequestMapping("/list")
    public Map findAll(){
        List<Student> list = biz.getStuList();
        Map map = new HashMap();
        map.put("isOk",true);
        map.put("students", list);
        map.put("msg","学生信息加载成功");
        return map;
    }

    @RequestMapping("/select")
    public Map findByName(@RequestParam String name){
        Student students = biz.getStudentByName(name);
        Map result = new HashMap<>();
        if(students!=null){
            result.put("isOk", true);
            result.put("students", students);
            result.put("msg", "查询成功");
        } else {
            result.put("isOk", false);
            result.put("msg", "未找到该学生");
        }
        return result;
    }

    @RequestMapping("/selectid")
    public Map findById(@RequestParam String id){
        Student students = biz.getStudentById(id);
        Map result = new HashMap<>();
        if(students!=null){
            result.put("isOk", true);
            result.put("students", students);
            result.put("msg", "查询成功");
        } else {
            result.put("isOk", false);
            result.put("msg", "未找到相关学生");
        }
        return result;

    }

    @RequestMapping("/del")
    public Map del(String id){
        boolean isOk = biz.removeStu(id);
        Map map = new HashMap();
        if(isOk){
            map.put("isOk",true);
            map.put("msg","删除成功");
        }else{
            map.put("isOk",false);
            map.put("msg","删除失败");
        }
        return map;
    }
    @RequestMapping("/add")
    public Map add(Student stu){
        boolean isOk = biz.addStu(stu);
        Map map = new HashMap();
        if(isOk){
            System.out.println(stu.getId());
            map.put("isOk",true);
            map.put("msg","注册成功");
        }else{
            map.put("isOk",false);
            map.put("msg","注册失败");
        }
        return map;
    }
    @RequestMapping("/login")
    public Map login(Student stu, HttpSession session){
        stu = biz.checkLogin(stu);
        session.setAttribute("login_stu",stu);
        Map map = new HashMap();
        map.put("isOk",true);
        map.put("login_stu",stu);
        map.put("msg","登录成功");
        return map;
    }

    @RequestMapping("/update")
    public Map update(Student student){
        this.biz.updateStudent(student);
        Map result = new HashMap<>();
        result.put("isOk",true);
        result.put("msg","修改成功");
        result.put("student",student);
        return result;
    }

    @RequestMapping("/logouot")
    public Map logout(HttpSession session){
        Map map = new HashMap();
        try {
            session.invalidate();
            map.put("isOk",true);
            map.put("msg","退出成功");
        }catch (Exception e){
            map.put("isOk",false);
            map.put("msg","退出失败："+e.getMessage());
        }
        return map;
    }

    public void setBiz(StudentBiz biz) {
        this.biz = biz;
    }
}
