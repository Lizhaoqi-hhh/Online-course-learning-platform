package com.lzq.OnlineCourse.biz;

import com.lzq.OnlineCourse.entity.Student;
import com.lzq.OnlineCourse.mapper.StudentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class StudentBiz {
    @Autowired  //由Spring创建对象并通过setter方法注入
    private StudentMapper mapper;

    public List<Student> getStuList(){
        return mapper.selectStus();
    }

    public Student getStudentById(String id){
        return this.mapper.selectStuById(id);
    }

    public Student getStudentByName(String name){
        return this.mapper.selectStudentByName(name);
    }

    public boolean addStu(Student stu){
        return mapper.insertStu(stu)>0;
    }
    public boolean removeStu(String id){
        return mapper.deleteStuById(id)>0;
    }

    public Student checkLogin(Student stu){
        Student dbstu= mapper.selectStuById(stu.getId());
        if(dbstu!=null && dbstu.getPwd().equals(stu.getPwd())){
            dbstu.setPwd(null);
            return dbstu;
        }else {
            throw new RuntimeException("登录失败");
        }
    }

    public void updateStudent(Student student){
        this.mapper.updateStudent(student);
    }

    public void setMapper(StudentMapper mapper) {
        this.mapper = mapper;
    }
}
