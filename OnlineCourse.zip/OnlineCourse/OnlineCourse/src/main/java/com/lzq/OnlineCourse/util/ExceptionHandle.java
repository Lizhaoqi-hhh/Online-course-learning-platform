package com.lzq.OnlineCourse.util;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class ExceptionHandle {
    @org.springframework.web.bind.annotation.ExceptionHandler
    @ResponseBody
    public Map JsonError(RuntimeException e){
        Map map = new HashMap();
        map.put("isOk",false);
        map.put("msg",e.getMessage());
        return map;
    }
}
