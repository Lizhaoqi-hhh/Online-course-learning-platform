package com.lzq.OnlineCourse.interceptor;

import com.lzq.OnlineCourse.entity.Admin;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
public class LoginInterceptor implements HandlerInterceptor {//自定义interceptor并重写接口中三个抽象方法
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        Object ad = request.getSession().getAttribute("login_ad");
        Object stu = request.getSession().getAttribute("login_stu");
        System.out.println("corrent ad"+ad);
        System.out.println("corrent stu"+stu);
        if (ad == null&&stu==null) {
            throw new RuntimeException("用户未登录，登录后才能访问哦~");
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }
}
