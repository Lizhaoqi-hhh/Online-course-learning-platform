package com.lzq.OnlineCourse.biz;

import com.lzq.OnlineCourse.entity.Course;
import com.lzq.OnlineCourse.mapper.CourseMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CourseBiz {
    @Autowired  //由Spring创建对象并通过setter方法注入
    private CourseMapper mapper;
    //查看列表
    public List<Course> getCourseList(){
        return mapper.selectCourse();
    }

    public Course getCourseByTitle(String title){
        return this.mapper.selectCourseByTitle(title);
    }

    public boolean addCourse(Course course){
        return mapper.insertCourse(course)>0;
    }
    public boolean removeCourse(int id){
        return mapper.deleteCourseById(id)>0;
    }

    public void updateCourse(Course course){
        this.mapper.updateCourse(course);
    }

    public void setMapper(CourseMapper mapper) {
        this.mapper = mapper;
    }
}
