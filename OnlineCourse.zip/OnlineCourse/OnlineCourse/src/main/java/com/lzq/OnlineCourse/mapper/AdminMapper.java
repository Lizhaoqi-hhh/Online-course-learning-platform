package com.lzq.OnlineCourse.mapper;

import com.lzq.OnlineCourse.entity.Admin;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface AdminMapper {

    @Select("select * from t_ad")
    List<Admin> selectAd();

    @Select("select * from t_ad where ID=#{id}")
    Admin selectAdById(String id);

    @Insert("insert into t_ad values (#{id},#{pwd})")
    int insertAd(Admin stu);

    @Delete("delete from t_ad where ID=#{id}")
    int deleteAdById(String id);


}
